<?php
$a=array("jay","vraj","roshan","rohit","smit","ronak","manish");
echo$a;
?>